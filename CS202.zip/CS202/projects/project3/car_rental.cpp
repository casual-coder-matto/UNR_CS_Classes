#include <iostream>
#include "car_rental.h"
using namespace std;

int rental_car::get_year()
{
    return m_year;
}
char* rental_car::get_make(char* destination, char* source)
{
    char temp[makeAndModelMax];
    //char* destination = destination;
    int l = 0;

    for(int i = 0; *source != '\0'; i++)
    {
        temp[i] = *source;
        source++;//
        l++;
    }

    for(int i = 0; i < l; i++)
    {
        *destination = temp[i];
        destination++;//
    }
    *destination = '\0';

    for(int i = 0; i < 10; i++)
    {
        source[i] = '\0';
    }

    return destination;
}
char* rental_car::get_model(char* destination, char* source)
{
    char temp[makeAndModelMax];
    //char* destination = destination;
    int l = 0;

    for(int i = 0; *source != '\0'; i++)
    {
        temp[i] = *source;
        source++;//
        l++;
    }

    for(int i = 0; i < l; i++)
    {
        *destination = temp[i];
        destination++;//
    }
    *destination = '\0';

    for(int i = 0; i < 10; i++)
    {
        source[i] = '\0';
    }

    return destination;
}
float rental_car::get_price()
{
    return m_price;
}
bool rental_car::get_available()
{
    return m_available;
}

void set_year(int year, rental_car car)
{
    car.m_year = year;
}

void set_make(char* destination, char* source)
{
    char temp[makeAndModelMax];
    //char* destination = destination;
    int l = 0;

    for(int i = 0; *source != '\0'; i++)
    {
        temp[i] = *source;
        source++;//
        l++;
    }

    for(int i = 0; i < l; i++)
    {
        *destination = temp[i];
        destination++;//
    }
    *destination = '\0';

    for(int i = 0; i < 10; i++)
    {
        source[i] = '\0';
    }
}

void set_model(char* destination, char* source)
{
    char temp[makeAndModelMax];
    //char* destination = destination;
    int l = 0;

    for(int i = 0; *source != '\0'; i++)
    {
        temp[i] = *source;
        source++;//
        l++;
    }

    for(int i = 0; i < l; i++)
    {
        *destination = temp[i];
        destination++;//
    }
    *destination = '\0';

    for(int i = 0; i < 10; i++)
    {
        source[i] = '\0';
    }
}

void set_price(float price, rental_car car)
{
    car.m_price = price;
}

void set_available(bool available, rental_car car)
{
    car.m_available = available;
}

void print(rental_car car)
{
    cout << car.m_year << car.m_make << car.m_model << car.m_price << car.m_available << endl;
}