//Mattew Neilll project 2
#include <iostream>
#include <fstream>
#include "car_rental.h"
using namespace std;

struct rentalAgency
{
    char name[256];
    int zip;
    rental_car rcar[5];
};

void input(char filei[], rentalAgency agencies[]);
//void print();
//void estimate();
//void expense();
//void print_file();
//void print_file();

int mystrlength(char* str);
char* mystrcopy(char* destination, const char* source);
char* mystrconcat(char* destination, const char* source);
int mystrcomp(char* str1, char* str2);

//main
int main()
{
    //just to clarify this is the main function
    //it functions as the main
    int n = 0;
    char filei[15], fileo[15];
    rentalAgency agencies[3];

    while(n < 6)
    {
        cout << "1 - Input file\n2 - Print to terminal\n3 - Estimate renatl cost\n4 - Find most expensive\n5 - Print to file\n6 - Exit\nEnter option:";
        cin >> n;
        switch(n)
        {
            case 1:
            input(filei, agencies);
            break;
            case 2:
            //print();
            break;
            case 3:
            //estimate();
            break;
            case 4:
            //expense();
            break;
            case 5:
            //print_file();
            break;
        }
    }

   return 0;
}

void input(char filei[], rentalAgency agencies[])
{
    cout << "Enter the name of the input file you wish to read from:";
    cin >> filei;

    ifstream inputfile;
    inputfile.open(filei);

    for(int i = 0; i < 3; i ++)
    {
        inputfile >> agencies[i].name
        >> agencies[i].zip;
        for(int n = 0; n < 5; n++)
        {
            inputfile >> agencies[i].rcar[n].m_year
            >> agencies[i].rcar[n].m_make
            >> agencies[i].rcar[n].m_model
            >> agencies[i].rcar[n].m_price
            >> agencies[i].rcar[n].m_available;
        }
    }

    for(int i = 0; i < 3; i ++)
    {
        cout << agencies[i].name
        << agencies[i].zip;
        for(int n = 0; n < 5; n++)
        {
            cout << agencies[i].rcar[n].m_year
            << agencies[i].rcar[n].m_make
            << agencies[i].rcar[n].m_model
            << agencies[i].rcar[n].m_price
            << agencies[i].rcar[n].m_available;
        }
    }
}


























int mystrlength(char* str)
{
    int l = 0;

    while(*str++ != '\0')
    {
        l++;
    }
    
    return l;
}

char* mystrcopy(char* destination, char* source)
{
    char temp[50];
    //char* destination = destination;
    int l = 0;

    for(int i = 0; *source != '\0'; i++)
    {
        temp[i] = *source;
        source++;//
        l++;
    }

    for(int i = 0; i < l; i++)
    {
        *destination = temp[i];
        destination++;//
    }
    *destination = '\0';

    for(int i = 0; i < 10; i++)
    {
        source[i] = '\0';
    }

    return destination;
}

char* mystrconcat(char* destination, char* source)
{
    //char* destination = destination;

    for(int i = 0; *destination != '\0'; i++)
    {
        destination++;//
    }

    for(int i = 0; *source != '\0'; i++)
    {
        *destination++ = *source++;
    }
    *destination = '\0';

    return destination;
}

int mystrcomp(char* str1, char* str2)
{
    int ascii_1, ascii_2;

    while(*str1 != '\0' && *str2 != '\0')
    {
        ascii_1 = (int)*str1++;
        ascii_2 = (int)*str2++;

        if(ascii_1 < 91 && ascii_1 > 65)
        {
            ascii_1 = ascii_1 + 32;
        }
        if(ascii_2 < 91 && ascii_2 > 65)
        {
            ascii_2 = ascii_2 + 32;
        }

        if(ascii_1 < ascii_2)
        {
            return 1;
        }
        else if(ascii_2 < ascii_1)
        {
            return -1;
        }
    }
    return 0;
}