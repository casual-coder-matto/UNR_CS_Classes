#pragma once
#define makeAndModelMax 256

class rental_car
{
    public:
        int m_year;
        char m_make[makeAndModelMax];
        char  m_model[makeAndModelMax];
        float m_price;
        bool m_available;
        rental_car();
        rental_car(int year, char make[], char model[], float price, bool available);
        int get_year();
        char* get_make(char* destination, char* source);
        char* get_model(char* destination, char* source);
        float get_price();
        bool get_available();
        void set_year(int year);
        void set_make(char* destination, char* source);
        void set_model(char* destination, char* source);
        void set_price(float price);
        void set_available(bool avaiable);
        void print(char* destination, char* source);
};