#include <iostream>
#include <cstring>
#include "Vehicle.h"
#include "Car.h"
using namespace std;

Car::Car():
    m_throttle(0)
{
    cout << "Car: Default-ctor" << endl;
}

Car::Car(const float* lla):
    Vehicle(lla)
{
    cout << "Car: Parametized-ctor" << endl;
}

Car::Car(const Car &obj):
    Vehicle(obj)
{
    cout << "Car: Copy-ctor" << endl;
}

Car::~Car()
{
    cout << "Car: Dtor" << endl;
}

void Car::setThrottle(const int throttle)
{
    m_throttle = throttle;
}

const int Car::getThrottle() const { return m_throttle; }

void Car::Move(const float* lla)
{
    
    cout << "Car: DRIVE to destination, with throttle @ 75 " << endl;

    this-> drive( 75 );
    this-> setLLA( lla );
}

void Car::drive(const int throttle)
{
    this->setThrottle(throttle);
}

void Car::operator=(const Car &other)
{
    cout << "Car: Assignment" << endl;
    this-> setLLA(other.getLLA());
    this-> setThrottle(other.getThrottle());
}

void Car::serialize(ostream& os) const
{
    const float *ptr = this->getLLA();
    cout << "Car: Throttle: " << this-> getThrottle()
    << " @ [" << *ptr << ", ";
    ptr++;
    os << *ptr << ", ";
    ptr++;
    os << *ptr << ']';
}