//Mattew Neilll project 2
#include <iostream>
#include <fstream>
using namespace std;

char* mystrcopy(char* destination, const char* source);
char* mystrconcat(char* destination, const char* source);
int mystrcomp(char* str1, char* str2);

//main
int main()
{
    
    return 0;
}

int mystrlength(char* str)
{
    int l = 0;

    while(*str++ != '\0')
    {
        l++;
    }
    
    return l;
}

char* mystrcopy(char* destination, char* source)
{
    char temp[50];
    //char* destination = destination;
    int l = 0;

    for(int i = 0; *source != '\0'; i++)
    {
        temp[i] = *source;
        source++;//
        l++;
    }

    for(int i = 0; i < l; i++)
    {
        *destination = temp[i];
        destination++;//
    }
    *destination = '\0';

    for(int i = 0; i < 10; i++)
    {
        source[i] = '\0';
    }

    return destination;
}

char* mystrconcat(char* destination, char* source)
{
    //char* destination = destination;

    for(int i = 0; *destination != '\0'; i++)
    {
        destination++;//
    }

    for(int i = 0; *source != '\0'; i++)
    {
        *destination++ = *source++;
    }
    *destination = '\0';

    return destination;
}

int mystrcomp(char* str1, char* str2)
{
    int ascii_1, ascii_2;

    while(*str1 != '\0' && *str2 != '\0')
    {
        ascii_1 = (int)*str1++;
        ascii_2 = (int)*str2++;

        if(ascii_1 < 91 && ascii_1 > 65)
        {
            ascii_1 = ascii_1 + 32;
        }
        if(ascii_2 < 91 && ascii_2 > 65)
        {
            ascii_2 = ascii_2 + 32;
        }

        if(ascii_1 < ascii_2)
        {
            return 1;
        }
        else if(ascii_2 < ascii_1)
        {
            return -1;
        }
    }
    return 0;
}