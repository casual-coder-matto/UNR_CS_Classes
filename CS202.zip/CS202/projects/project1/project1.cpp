#include <iostream>
#include <fstream>
using namespace std;

void ask(char f[3][15]);
void read(char f[3][15], char names[10][9], int order[10], int i);
void sortLength(char names[10][9], int length[10], int order[10]);
void copystring(char copy[9], char names[10][9], int g);
void write(char f[3][15], char names[10][9], int order[10], int i);
void alphabet(char f[3][15], char names[10][9]);


int main()
{
    char f[3][15];
    char names[10][9];
    int length[10];
    int order[10] = {1,2,3,4,5,6,7,8,9,10};

    ask(f);
    int i = 0;
    read(f, names, order, i);
    sortLength(names, length, order);
    i = 1;
    write(f, names, order, i);
    alphabet(f, names);


    return 0;
}

void ask(char f[3][15])
{
    cout << "Please enter the name of the Input, Output Length Sorted and Output Alphabet Sorted files respectively.\n";
    
    for (int r = 0; r < 3; r++)
    {
        cin >> f[r];
    }

}

void read(char f[3][15], char names[10][9], int order[10], int i)
{
    ifstream input;
    input.open(f[0]);

    for (int m = 0; m < 10; m++)
    {
        input >> names[m];
    }
    cout << "----------\n";

    if (i == 0){
    for (int m = 0; m < 10; m++)
    {
        cout << order[m] << " " << names[m] <<'\n';
    }

    cout << "----------\n";
    }
    input.close();
    //cout << "CLOSED\n\n";

}

void sortLength(char names[10][9], int length[10], int order[10])
{
    for (int i = 0; i < 10; i++)
    {
        int l = 0;
        for (int j = 0; j < 9; j++)
        {
            if (names[i][j] == '\0'){break;}
            else{l++;}
        }
        length[i] = l;
    }
    //To check
    //for (int k = 0; k < 10; k++){cout << length[k] << " "; cout << '\n';}

    //sorter
    int placeholder1, placeholder2;
    char copy[9];
    
    for (int g = 0; g < 6; g++)
    {
        for (int g = 0; g < 9; g++)
        {   
            if (length[g] >= length[g+1])
            {
                placeholder1 = length[g+1];
                placeholder2 = order[g+1];
                length[g+1] = length[g];
                order[g+1] = order[g];
                length[g] = placeholder1;
                order[g] = placeholder2;
                copystring(copy, names, g);
            }
            //for (int k = 0; k < 10; k++){cout << length[k] << order[k] << names[k] << '\n';}
            //cout << "-------------------------\n";
        }
    }

    for (int k = 0; k < 10; k++){cout << order[k] << " " << names[k] << endl;}
    cout << "----------\n";
    
}

void copystring(char copy[9], char names[10][9], int g)
{
    for (int m = 0; m < 9; m++)
    {
        if (names[g+1][m] == '\0')
        {
            copy[m] = '\0';
            break;
        }
        copy[m] = names[g+1][m];
    }
    for (int m = 0; m < 9; m++)
    {
        if (names[g][m] == '\0')
        {
            names[g+1][m] = '\0';
            break;
        }
        names[g+1][m] = names[g][m];
    }
    for (int m = 0; m < 9; m++)
    {
        if (copy[m] == '\0')
        {
            names[g][m] = '\0';
            break;
        }
        names[g][m] = copy[m];
    }
}

void write(char f[3][15], char names[10][9], int order[10], int i)
{
    ofstream output;
    output.open(f[i]);

    if (output.is_open())
    {
        for (int m = 0; m < 10; m++)
        {
            output << order[m] << " " << names[m] << endl;
        }
        output.close();
    }
    else
    {
        cout << "error\n";
    }
}

void alphabet(char f[3][15], char names[10][9])
{
    int order[10] = {1,2,3,4,5,6,7,8,9,10};
    int i = 1;
    read(f, names, order, i);

    int ascii[10];

    for (int m = 0; m < 10; m++)
    {
        ascii[m] = int(names[m][0]);
    }
    for (int m = 0; m < 10; m++)
    {
        if (ascii[m] < 91 && ascii[m] > 65)
        {
            ascii[m] = ascii[m] + 32;
        }
    }

    int placeholder1, placeholder2;
    char copy[9];

    for (int g = 0; g < 10; g++)
    {
        for (int g = 0; g < 9; g++)
        {   
            if (ascii[g] > ascii[g+1])
            {
                placeholder1 = ascii[g+1];
                placeholder2 = order[g+1];
                ascii[g+1] = ascii[g];
                order[g+1] = order[g];
                ascii[g] = placeholder1;
                order[g] = placeholder2;
                copystring(copy, names, g);
            }
            if (ascii[g] == ascii[g+1])
            {
                int ascii_1 , ascii_2, n=1;

                do
                {
                    ascii_1 = (int)names[g][n];
                    ascii_2 = (int)names[g+1][n];

                    if(ascii_1 < 91 && ascii_1 > 65)
                    {
                        ascii_1 = ascii_1 + 32;
                    }
                    if(ascii_2 < 91 && ascii_2 > 65)
                    {
                        ascii_2 = ascii_2 + 32;
                    }

                    if(ascii_2 < ascii_1)
                    {
                        placeholder1 = ascii[g+1];
                    placeholder2 = order[g+1];
                    ascii[g+1] = ascii[g];
                    order[g+1] = order[g];
                    ascii[g] = placeholder1;
                    order[g] = placeholder2;
                    copystring(copy, names, g);
                    }
                    else if (ascii_1 < ascii_2)
                    {
                        break;
                    }
                    n++;
                }while (ascii_1 == ascii_2);
            }
        }
    }
   for (int k = 0; k < 10; k++){cout << order[k] << " " << names[k] << endl;}
    cout << "----------\n";

    i = 2;
    write(f, names, order, i);
}