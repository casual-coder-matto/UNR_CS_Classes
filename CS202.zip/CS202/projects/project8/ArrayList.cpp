#include "ArrayList.h"
#include "DataType.h"
#include <cstdlib>
using namespace std;

class ArrayList{
  private:
    DataType m_array;
    size_t m_size;
    size_t m_maxsize;
    void resize(size_t count)
    {
        ]
     }
  public:
    
};