#include "NodeQueue.h"
#include "DataType.h"
using namespace std;

NodeQueue::NodeQueue(){
    m_front = NULL;
    m_back = NULL;
}
NodeQueue::NodeQueue(size_t size, const DataType & value){
    Node *temp = new Node(value, NULL);
    m_front = temp;
    m_back = temp;
    for(size_t i = 0; i < size; i++){
        temp->m_next = new Node(value, NULL);
        temp = temp ->m_next;
    }
    m_back = temp;
}
NodeQueue::NodeQueue(const NodeQueue & other){
    m_front = new Node(other.m_front->data());
    Node *HeadCpy = m_front;
    Node *BodyCpy = other.m_front;
    while(BodyCpy->m_next != NULL){
        BodyCpy = BodyCpy->m_next;
        HeadCpy->m_next = new Node(BodyCpy->data());
        HeadCpy = HeadCpy->m_next;
    }
    HeadCpy ->m_next = NULL;
}
NodeQueue::~NodeQueue(){
    clear();
}

NodeQueue &NodeQueue::operator= (const NodeQueue & rhs){
    clear();
    m_front = new Node(rhs.m_front->data());
    Node *HeadCpy = m_front;
    Node *BodyCpy = rhs.m_front;
    while(BodyCpy->m_next != NULL){
        BodyCpy = BodyCpy->m_next;
        HeadCpy->m_next = new Node(BodyCpy->data());
        HeadCpy = HeadCpy->m_next;
    }
    m_back = HeadCpy;
    HeadCpy->m_next = NULL;
    return *this;
}
std::ostream &operator<<(std::ostream &os, const NodeQueue obj){
    obj.serialize(os);
    return os;
}

DataType & NodeQueue::front(){
    if(!empty()){
        return m_front->data();
    }
    exit(0);
}
const DataType & NodeQueue::front() const{
    if(!empty()){
        return m_front->data();
    }
    exit(0);
}
DataType & NodeQueue::back(){
    if(!empty()){
        return m_back->data();
    }
    exit(0);
}
const DataType & NodeQueue::back() const{
    if(!empty()){
        return m_back->data();
    }
    exit(0);
}

void NodeQueue::push(const DataType & value){
    Node *temp = new Node(value);
    m_back->m_next = temp;
    m_back = temp;
}
 
void NodeQueue::pop(){
    if(!empty()){
        Node *temp = m_front->m_next;
        delete m_front;
        m_front = temp;
    }
}

size_t NodeQueue::size() const{
    size_t i = 0;
    Node *temp = m_front;
    while(temp->m_next != NULL){
        temp = temp->m_next;
        i++;
    }
    return i;
}

bool NodeQueue::empty() const{
    return m_front==NULL;
}

bool NodeQueue::full() const{
    return false;
}

void NodeQueue::clear(){
    Node *kill = m_front;
    Node *track = m_front;
    while(track != NULL){
        track = track->m_next;
        delete kill; 
        kill = track;
    }
    m_front = NULL;
    m_back = NULL;
}

void NodeQueue::serialize(std::ostream & os) const{
    Node *temp = m_front;
    while(temp->m_next != NULL){
        os << temp->data() << endl;
    }
}