#include "ArrayQueue.h"
#include "DataType.h"
using namespace std;

ArrayQueue::ArrayQueue(){m_size=0;m_front=0;m_back=0;}
ArrayQueue::ArrayQueue(size_t count, const DataType & value){
    for(int i = 0; i<count; i++)
    {
        m_array[i] = value;
    }
    m_size = count;
    m_back = count;
    m_front = 0;
}
ArrayQueue::ArrayQueue(const ArrayQueue &obj){
    for(int i = 0; i < obj.m_size; i++)
    {
        m_array[i] = obj.m_array[i];
    }
    m_size = obj.m_size;
    m_front = obj.m_front;
    m_back = obj.m_back;
}
ArrayQueue:: ~ArrayQueue(){}
//return type, what class is accessed, function accessed
ArrayQueue& ArrayQueue::operator=( ArrayQueue &obj){
    for(int i = 0; i < obj.m_size; i++)
    {
        m_array[i] = obj.m_array[i];
    }
    m_size = obj.m_size;
    m_front = obj.m_front;
    m_back = obj.m_back;
    return obj;
}

DataType & ArrayQueue::front(){
    return m_array[m_front];
}
const DataType & ArrayQueue::front() const{
    return m_array[m_front];
}

DataType & ArrayQueue::back(){
    return m_array[m_back];
}
const DataType & ArrayQueue::back() const{
    return m_array[m_back];
}

void ArrayQueue::push(const DataType & value){
    if(m_size != ARRAY_MAX)
    {
        m_back++;
        m_size++;
        m_array[m_back] = value;
    }
}

void ArrayQueue::pop(){
    if(m_back != 0)
    {
        for(int i = 0; i < m_size; i++)
        {
            m_array[i] = m_array[i+1];
        }
        m_size--;
        m_back--;
    }
}

size_t ArrayQueue::size() const{
    return m_size;
}

bool ArrayQueue::empty() const{
    if(m_back == 0)
    {
        return 1;
    }else
    {
        return 0;
    }
    
}

bool ArrayQueue::full() const{
    if(m_size == ARRAY_MAX)
    {
        return 1;
    }else
    {
        return 0;
    }
}

void ArrayQueue::clear(){
    m_size = 0;
    m_back = 0;
}

void ArrayQueue::serialize(std::ostream & os) const{
    for(int i = 0; i < m_size; i++)
    {
        os << m_array[i] << endl;
    }
}

//memorize this format for overloading <<>>
std::ostream &operator<<(std::ostream & os, const ArrayQueue &obj){
    os << "The size of the array is:" << obj.m_size << endl;
    os << "The content of the array is:" << endl;
    obj.serialize(os);

    return os;
}
