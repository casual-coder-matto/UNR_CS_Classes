//Matthew Neill CS202
#include <iostream>
#include "ArrayStack.h"
#include "NodeStack.h"
using namespace std;

class DataType{

friend std::ostream & operator<<(std::ostream & os, const DataType & dataType);
friend std::istream & operator>>(std::istream & is, DataType & dataType);

  public:
    DataType();
    DataType(int intVal, double doubleVal);
	DataType(const DataType & other);
	
    bool operator==(const DataType & rhs) const;
    DataType & operator= (const DataType & rhs);
    
    int getIntVal() const;
    void setIntVal(int i);  
    double getDoubleVal() const;
    void setDoubleVal(double d);

  private:
    int m_intVal;
    double m_doubleVal;
};



int main()
{															
	ArrayStack<int> aempty;
	NodeStack<int> nempty;
	
	cout << "Default ctors\nArrayStack: " << aempty
			  << "NodeStack: " << nempty << endl;														
	DataType garbage(7, 7.0);
	DataType alsogarbage(12, 12.0);
	ArrayStack<int> gettingsomewhere(5, 1);
	NodeStack<int> alsogettingsomewhere(20, 3);
	
	cout << "Parameterized ctors\nArrayStack: " 
			  << gettingsomewhere << "NodeStack: " << alsogettingsomewhere	
			  << endl;
	
  //COPY CTOR 															
	ArrayStack<int> cat(gettingsomewhere);
	NodeStack<int> kitty(alsogettingsomewhere);
	
	cout << "Copy ctors\nArrayStack: " << cat << "NodeStack: "
		<< kitty << endl;

  //ASSIGNMENT OPERATOR 													
	cout << "Assignemnt operator: Changing default to copy.\nOld "
			  << "ArrayStack: " << aempty;
	aempty = cat;
	cout << "New ArrayStack: " << aempty;
	
	cout << "\nOld NodeStack: " << nempty;
	nempty = kitty;
	cout << "New NodeStack: " << nempty;

  //TOP FUNCTION															
	DataType value(13, 13.0);
	DataType nodeValue(26, 26.0);
	ArrayStack<int> aTop(4, 8);
	NodeStack<int>  nTop(1, 5);
	
	cout << "\nTop value of stack:\nArrayStack: " << aTop.top()
		<< "\nNodeStack: " << nTop.top() << endl;
	
  //PUSH FUNCTION 															
	DataType aPush(10,10.0);
	DataType nPush(11, 11.0);
	aTop.push(3);
	nTop.push(44);
	
	cout << "\nPush function:\nArrayStack: " << aTop << "NodeStack: "
	<< nTop << endl;
			 
  //POP FUNCTION															
	cout << "Pop function:\nOld ArrayStack: " << aTop  
			  << "Old NodeStack: " << nTop;
	aTop.pop();
	nTop.pop();
	cout << "New ArrayStack: " << aTop << "New NodeStack: " << nTop;
	
  //SIZE FUNCTION															
	cout << "\nSize function:\nArrayStack: " << aTop.size() 
			  << "\nNodeStack: " << nTop.size() << endl;

  //EMPTY FUNCTION															
	ArrayStack<int> empty;
	NodeStack<int>  notfull;
	
	cout << "\nTesting empty function:\nEmpty ArrayStack: " << boolalpha
			  << empty.empty() << "\nRegular Array Stack: " << boolalpha
			  << aTop.empty() << "\nEmpty NodeStack: " << boolalpha 
			  << notfull.empty() << "\nRegular NodeStack: " << boolalpha
			  << nTop.empty() << endl;
		  
  //FULL FUNCTION															
	ArrayStack<int> full(999, 1);
	NodeStack<int> neverfull(1001, 2);
	cout << "\nTesting full function:\nFull ArrayStack: " 
			  << boolalpha << full.full() << "\nRegular ArrayStack: " 
			  << boolalpha << aTop.full() << "\nNodeStacks have no limit, "
			  << "NodeStack of size 1001: " << boolalpha 
			  << neverfull.full() << endl;
			  		  
  //CLEAR FUNCTION															
	cout << "\nClear function:\nFull ArrayStack: ";
	full.clear();
	cout << full << "\nNodeStack: ";
	neverfull.clear();
	cout << neverfull << endl;
	
	//Tests done
	cout << "Tests Done!" << endl;
	

	return 0;
}


DataType::DataType()
 : m_intVal(0),
   m_doubleVal(0)
{
}

DataType::DataType(int intVal, double doubleVal)
 : m_intVal(intVal),
   m_doubleVal(doubleVal)
{
}

DataType::DataType(const DataType & other)
 : m_intVal(other.m_intVal),
   m_doubleVal(other.m_doubleVal)
{
}
	
bool DataType::operator==(const DataType& rhs) const{
  return m_intVal==rhs.m_intVal && m_doubleVal==rhs.m_doubleVal;
}

DataType& DataType::operator=(const DataType& rhs){
  if (this != &rhs){
    m_intVal = rhs.m_intVal;
    m_doubleVal = rhs.m_doubleVal;
  }
  return *this;
}

int DataType::getIntVal() const{
  return m_intVal;
}

void DataType::setIntVal(int i){
  m_intVal = i;
}

double DataType::getDoubleVal() const{
  return m_doubleVal;
}

void DataType::setDoubleVal(double d){
  m_doubleVal = d;
}

std::ostream & operator<<(std::ostream& os, const DataType & dt){
  os << "{" << dt.m_intVal << "," << dt.m_doubleVal << "}";
  return os;
}

std::istream & operator>>(std::istream & is, DataType & dt){
  char in_buf[255];
  is >> in_buf;
  dt.m_doubleVal = atof(in_buf);
  dt.m_intVal = (int)dt.m_doubleVal;
  dt.m_doubleVal -= dt.m_intVal;
  return is;
}

