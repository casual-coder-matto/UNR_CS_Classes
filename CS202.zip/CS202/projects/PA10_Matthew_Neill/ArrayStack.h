#pragma once

#include <iostream>

template <typename T> class ArrayStack;
template <typename T> std::ostream & operator<<(std::ostream & os, 
						const ArrayStack<T> & arrayStack);
									
const size_t MAX_STACKSIZE = 1000;

template <typename T>
class ArrayStack{
	
  friend std::ostream & operator<< <> (std::ostream & os, 
								const ArrayStack<T> & arrayStack); 
  public:
	ArrayStack():m_top(0){;}

	ArrayStack(size_t count, const T & value){
		if(count < (MAX_STACKSIZE) && count >= 1){
			size_t i = 0;
			m_top = count;
			while(i <= m_top){
				m_container[i] = value;
				i++;
			}
		}else{
			std::cout << "INVALID COUNT NUMBER, ARRAY NOT INITIALIZED" 
					  << std::endl;
			m_top = 0;
		}
	}

	ArrayStack(const ArrayStack<T> & other){
		size_t i = 0;
		m_top = other.m_top;
		while(i <= m_top){
			m_container[i] = other.m_container[i];
			i++;
		}
	}

	~ArrayStack(){
	clear();	
	std::cout << "ARRAYSTACK DTOR CALLED." << std::endl;
	}

	ArrayStack & operator= (const ArrayStack<T> & rhs){
		if(this != &rhs){
			size_t i = 0;
			m_top = rhs.m_top;
			while(i < m_top){
				m_container[i] = rhs.m_container[i];
				i++;
			}
			return *this;
		}else{
			return *this;
		}
	}

	T & top(){return m_container[m_top];}

	const T & top() const{return m_container[m_top];}

	void push(const T & value){
		if((m_top) < MAX_STACKSIZE){
			++m_top;
			m_container[m_top] = value;
		}else{
			std::cout << "OVERFLOW IMMENINT IF PUSHED, NO GO." << std::endl;
		}
	}

	void pop(){
		if(!empty()){
			m_container[m_top] = -2000;
			m_top -= 1;
		}else{
			std::cout << "This Stack is empty!" << std::endl;
		}
	}

	size_t size() const{
		return m_top;
	}

	bool empty() const{
		if(m_top == 0){
			return true;
		}else{
			return false;
		}
	}

	bool full() const{
		if(m_top == (MAX_STACKSIZE - 1)){
			return true;
		}else{
			return false;
		}
	}

	void clear(){
		if(!empty()){
			while(!empty()){
				pop();
				if(empty()){
					std::cout << "This Stack is now empty." << std::endl;
				}
			}
		}else{
			std::cout << "This Stack is empty!" << std::endl;
		}
	}

	void serialize(std::ostream & os) const{
		if(!empty()){
			os << '[';
			size_t i = 0;
			while(i < m_top){
				if((m_top - 1) == i){
					os << m_container[i] << ']';
				}else{
					os << m_container[i] << ", ";
				}
				i++;
			}
		}else{
			os << "This Stack is empty!!!";
		}
		os << std::endl;
	}
	


  private:
	T m_container[MAX_STACKSIZE];
	size_t m_top;
};

template<typename T>
std::ostream & operator<< (std::ostream & os, 
								const ArrayStack<T> & arrayStack){
	arrayStack.serialize(os);
	return os;
}