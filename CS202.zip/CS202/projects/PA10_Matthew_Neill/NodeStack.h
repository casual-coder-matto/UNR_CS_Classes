#pragma once

#include <iostream>

template <typename T> class NodeStack;
template <typename T> std::ostream & operator<<(std::ostream & os,
                   const NodeStack<T> & nodeStack);


template <typename T>
class Node{
	 
	friend class NodeStack<T>;
	    
  public: 
	Node(): m_next(NULL){;} 
	Node(const T & data, Node<T> * next = NULL):m_next(next), m_data(data){;}
	T & data(){return m_data;} 
	const T & data() const{return m_data;} 
  private: 
	Node * m_next; 
	T m_data;                                   
}; 

template <typename T>
class NodeStack{
  friend std::ostream & operator<< <> (std::ostream & os,
                   const NodeStack<T> & nodeStack);
  public:

	NodeStack():m_top(NULL){;}

	NodeStack(size_t count, const T & value=T()){
		if(count >= 1){
			size_t i = 0;
			m_top = NULL;
			while(i < count){
				push(value);
				i++;
			}
		}else{
			std::cout << "INVALID COUNT NUMBER, NODESTACK INITIAILZED WITH "
					  << "NULL VALUES." << std::endl;
			m_top = NULL;
		}
	}
            
	NodeStack(const NodeStack<T> & other){
		m_top = new Node<T>(other.m_top->data(), NULL);
		Node<T> * othercpy = other.m_top;
		Node<T> * thiscpy = m_top;
		
		while(othercpy->m_next){
			thiscpy->m_next = new Node<T>(othercpy->data(), NULL);
			thiscpy = thiscpy->m_next;
			othercpy = othercpy->m_next;
		}
		
	}
                      
	~NodeStack(){
		clear();
		std::cout << "NODESTACK DTOR CALLED." << std::endl;
	}                                                 

    NodeStack &operator=(const NodeStack<T> & rhs){
		if(this != &rhs){
			m_top = new Node<T>(rhs.m_top->data(), NULL);
			Node<T> * topcpy = m_top;
			Node<T> * rhscpy = rhs.m_top;
			while(rhscpy->m_next != NULL){
				topcpy->m_next = new Node<T>(rhscpy->data(), NULL);
				rhscpy = rhscpy->m_next;
				topcpy = topcpy->m_next;
			}
			return *this;
		}else{
			return *this;
		}
	}

	T & top(){
		return m_top->data();
	}                                     

	const T & top() const{
		return m_top->data();
	}                           

	void push(const T & value){
		if(!empty()){
			Node<T> * newNode = new Node<T>(value, NULL);
			newNode->m_next = m_top;
			m_top = newNode;
		}else{
			m_top = new Node<T>(value, NULL);
		}
	}          

	void pop(){
		if(!empty()){
			Node<T> * topNode = m_top;
			m_top = m_top->m_next;
			delete topNode;
			topNode = NULL;
		}else{
			std::cout << "This Stack is empty!" << std::endl;
		}
	}								 

	size_t size() const{
		size_t i = 0;
		if(!empty()){
			Node<T> *size = m_top;
			while(size != NULL){
				i++;
				size = size->m_next;
				}
			} 
		return i;
	}                
	
	bool empty() const{
		if(m_top == NULL){
			return true;
		}else{
			return false;
		}
	}

    bool full() const{return false;}             

	void clear(){
		if(!empty()){
			while(!empty()){
				pop();
				if(empty()){
					std::cout << "This Stack is now empty." << std::endl;
				}
			}
		}else{
			std::cout << "This Stack is empty!" << std::endl;
		}
	}                                            

	void serialize(std::ostream & os) const{
		if(!empty()){
			os << '[';
			Node<T> * travel = m_top;
			while(travel != NULL){
				if(travel->m_next == NULL){
					os << travel->data() << ']';
				}else{
					os << travel->data() << ", ";
				}
				travel = travel->m_next;
			}
		}else{
				os << "This Stack is empty!";
			
		}
		os << std::endl; 
	}

  private: 
	Node<T> * m_top;
};	

template<typename T>
std::ostream & operator<< (std::ostream & os,
                   const NodeStack<T> & nodeStack){
	nodeStack.serialize(os); 
	return os;
} 