//Matthew Neill
//CS202
//Proj4.cpp

#include <iostream>
#include <fstream>
#include "Car.h"
#include "Agency.h"
#include "Sensors.h"
using namespace std;

void read(Agency *agency);

int main(){

    int input;
    Agency agency;
    int positions[5] = {0,1,2,3,4};
    
    do{
        cout << "\n1 - Input File Name\n2 - Print\n3 - Number of Sensors\n4 - Most Expensive Car\n5 - Exit" << endl;
        cout << "Enter option: ";
        cin >> input;
        cout << endl;
        switch(input){
            case 1: 
                read(&agency);
                break; 
            case 2: 
                agency.printData();
                break;
            case 3: 
                break;
            case 4: 
                break;
        }
    }while(input != 5);

    return 0;
}

void read(Agency* agency)
{
    char fileIn[100];
    cout << "Please enter input file name: ";
    cin >> fileIn;

    ifstream inputFile;
    inputFile.open(fileIn);

    if(!inputFile)
    {
        cout << "Could not open file\n";
    }else
    {
        agency->readData(inputFile);
    }

    return;
}