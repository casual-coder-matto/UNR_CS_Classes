#include <iostream>
#include <vector>
#include <bits/stdc++.h>
using namespace std;

template <typename T>
int partition(T &data, int low, int high)
{
    int pivot = low +(high - low) / 2;
    int pivotVal = data[pivot];
    int i = low, j = high;
    int temp;
    while(i <= j){
        while(data[i] < pivotVal){
            i++;
        }
        while(data[j] > pivotVal){
            j--;
        }
        if(i <= j){
            temp = data[i];
            data[i]  = data[j];
            data[j] = temp;
            i++;
            j--;
        }
    }
    return (i);
}

template <typename T>
void vectorResort(T &data, int low, int high)
{
    if(low < high){
        int parIndex = partition(data, low, high);

        vectorResort(data, low, parIndex - 1);
        vectorResort(data, parIndex, high);
    }
}

template <typename T>
int vectorResearch(T &data, int L, int R, int x){
    if(R >= 1) {
        int mid = L + (R-1) / 2;
    
        if(data[mid] == x){
            return mid;
        }
        if(data[mid] > x){
            return vectorResearch(data, L, mid - 1, x);
        }
    }
    return -1;
}