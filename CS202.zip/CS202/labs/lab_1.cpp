#include <iostream>
using namespace std;

int main()
{
    char name[11];

    cout << "Enter a string of 10 characters:";
    cin >> name;

    int n=0, e=0, l=0;

    while (e == 0)
    {
        if (name[n] != '\0')
        {
            n++;
            l++;
        } else
        {
            e++;
        }
    }

    cout << "The length of the string is: " << l << "\n";

    return 0;
}