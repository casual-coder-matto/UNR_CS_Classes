#include <iostream>
using namespace std;

int* sumAppend(int *nums);

int main()
{
    int nums[5] = {2,7,1,3,0};

    sumAppend(nums);

    cout << *sumAppend(nums);
h
    return 0;
}

int* sumAppend(int *nums)
{
    int sum = 0;

    for(*nums = 0; nums != 0; nums++)
    {
        sum = sum + *nums;
    }
    *nums = sum;

    return nums;
}