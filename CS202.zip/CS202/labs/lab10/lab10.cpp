#include <iostream>

#include "DataType.h"

using namespace std;


class Node{
  friend class LinkedList;
  private:
    Node *m_link;
    DataType m_data;
  public:
    Node(Node *link, DataType data){
      m_link = link;
      m_data = data;
    }
    void setLink(Node *link){
      m_link = link;
    }
    void setData(DataType data){
      m_data = data;
    }
    Node *getLink(){
      return m_link;
    }
};


class LinkedList{
	
  public:    
  
    LinkedList();
    
    void push_back(const DataType & value); 	       

    size_t size() const;

  private:

    Node * m_head;
		
};

LinkedList::LinkedList()
{
  m_head = NULL;	
}

void LinkedList::push_back(const DataType & value){
  Node * n = new Node(NULL, value);
  if(m_head == NULL)
  {
    m_head = n;
  }else
  {
    for(Node *temp = m_head; temp -> m_link != NULL; temp = temp -> m_link)
    {
      temp -> m_link = n;
    }
  }
}

size_t LinkedList::size() const{
  size_t i = 0;
  for(Node *temp = m_head; temp != NULL; temp = temp ->m_link, i++)
  {}
  return i;
}


int main(){
	
	LinkedList ll;
	cout << endl << ll.size() << endl;
	
	DataType dt_01(0, 1.0);
	ll.push_back( dt_01 );
        cout << endl << ll.size() << endl;

	DataType dt_12(1, 2.0);
	ll.push_back( dt_12 );
        cout << endl << ll.size() << endl;
}


