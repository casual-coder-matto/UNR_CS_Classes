#include <iostream>

#include "Matrix.h"

Matrix::Matrix(int val){

}

bool Matrix::operator==(const Matrix & rhs) const{  

}

Matrix Matrix::transpose() const{  

}

std::ostream & operator<<(std::ostream & os, const Matrix & mat){  

}

std::istream & operator>>(std::istream & is, Matrix & mat){  

}

