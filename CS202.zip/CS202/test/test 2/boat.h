#pragma once

class boat
{
    int price;
    int speed;
    int size;
    int milage;
    int gas;
    char name[15];
    void sail(int distance, int gas);
};