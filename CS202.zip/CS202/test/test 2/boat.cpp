#include "boat.h"

void boat :: sail(int distance, int gas)
{
    int miles += distance;
};