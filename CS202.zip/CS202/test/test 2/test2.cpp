#include <iostream>
#include <fstream>
#include "boat.h"
using namespace std;

int main()
{

}