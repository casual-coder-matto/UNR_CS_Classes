#include <iostream>
#include "Book.h"
#include "ChildrenBook.h"
 
using namespace std;
int main()
{
    Client jDoe("John Doe");
    Book myBook("LOTR ROTC", Cover(true), &jDoe, 999);
    Client jDoeJr("John Doe Jr");
    ChildrenBook myChildBook("LOTR comic", true, Cover(false), &jDoeJr);
    Book * book_Pt;
    book_Pt = &myBook;
    cout << *book_Pt << endl;
    book_Pt = &myChildBook;
    cout << *book_Pt << endl;
    return 0;
}