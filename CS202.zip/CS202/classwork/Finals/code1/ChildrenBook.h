#pragma once
#include <iostream>
#include <string>
#include "Book.h"
using namespace std;

//possible ChildrenBook derived class globals, etc.
//fill derived class with return values, parameters, specifiers
class ChildrenBook: public Book{
  public:
//default ctor
ChildrenBook();
//parametrized ctor
ChildrenBook(char* title, Cover cover, const Client *client, const size_t serial, bool graphic);
//copy ctor
ChildrenBook(const ChildrenBook & oldBook);
//dtor
~ChildrenBook();
//assignment operator
ChildrenBook & operator=(const ChildrenBook & oldBook);
//get set methods
const bool getGraphic();
void setGraphic(const bool graphic);
//serialize method
void serialize();
//insertion operator
friend std::ostream & operator<<(std::ostream & os, const ChildrenBook & obj);
//data members
  private:
    bool m_graphic;
};

//default ctor
ChildrenBook::ChildrenBook()
{
  count++;
}
//parametrized ctor
ChildrenBook::ChildrenBook(char* title, Cover cover, const Client *client, const size_t serial, bool graphic):m_serial(count)
{
  count++;
  strcpy(m_title, title);
  m_cover = cover;
  setClient(client);
  m_graphic = graphic;
}
//copy ctor
ChildrenBook::ChildrenBook(const ChildrenBook & oldBook):m_serial(count)
{
  count++;
  strcpy(m_title, oldBook.m_title);
  m_cover = oldBook.m_cover;
  m_graphic = oldBook.m_graphic;
}
//dtor
ChildrenBook::~ChildrenBook()
{
//no dynamically allocated memory so not needed
}
//assignment operator
ChildrenBook & ChildrenBook::operator=(const ChildrenBook & oldBook)
{
  count++;
  strcpy(m_title, oldBook.m_title);
  m_cover = oldBook.m_cover;
  setClient(const oldBook.getClient());
  m_graphic = oldBook.m_graphic;

  return *this;
}
//get set meathods
const bool ChildrenBook::getGraphic()
{
  return m_graphic;
}
void ChildrenBook::setGraphic(const bool graphic)
{
  m_graphic = graphic;
}
//serialize method
void ChildrenBook::serialize(std::ostream & os)
{
  if(m_graphic)
  {
    os << "Graphic Novel";
  }
  os << "Title: " << m_title << endl;
  if(m_cover.GetValue())
  {
    os << "Hard cover" << endl;;
  }else{
    os << "Paper back" << endl;
  }
  os << "Serial Number: " << m_serial << endl;
  if (*m_client != NULL)  
  {   
    os << "Client: " << *m_client << endl;
  }

}
//insertion operator overload
std::ostream & operator<<(std::ostream & os, ChildrenBook & obj)
{
  os << obj.serialize();
  return os;
}