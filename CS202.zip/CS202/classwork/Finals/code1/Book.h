#pragma once 
#include <iostream>
#include <string>
#include "Cover.h"
#include "Client.h"
using namespace std;

//fill with return values, parameters, specifiers
class Book {
  public:
//default ctor
Book();
//parametrized ctor
Book(char* title, Cover cover, const Client *client, const size_t serial);
//copy ctor
Book(const Book & oldBook);
//dtor
~Book();
//assignment operator
Book & operator=(const Book & oldBook);
//get set meathods
const Cover getCover();
void setCover(Cover cover); 
const Client* getClient(); 
void setClient(const Client* client);
//serialize meathods
void serialize(std::ostream & os);
friend std::ostream & operator<<(std::ostream & os, const Book & obj);
//data members
  private:
    const Client *m_client;
  protected:
    char* m_title;
    Cover m_cover;
    static size_t count;
    const size_t m_serial;
};

//default ctor
Book::Book(): m_serial(count)
{
  count++;
}
//parametrized ctor
Book::Book(char* title, Cover cover, const Client *client, const size_t serial):m_serial(count)
{
  count++;
  strcpy(m_title, title);
  m_cover = cover;
  setClient(client);
}
//copy ctor
Book::Book(const Book & oldBook):m_serial(count)
{
  count++;
  strcpy(m_title, oldBook.m_title);
  m_cover = oldBook.m_cover;
}
//dtor
Book::~Book()
{
//not necessary, no new allocated data
}
//assignment operator
Book & Book::operator=(const Book & oldBook)
{
  count++;
  strcpy(m_title, oldBook.m_title);
  m_cover = oldBook.m_cover;
  setClient(oldBook.getClient());

  return *this;
}
//get set methods
const Cover Book::getCover()
{
  return m_cover;
}
void Book::setCover(Cover cover)
{
  m_cover = cover;
}
const Client* Book::getClient()
{
  return m_client;
}
void Book::setClient(const Client* client)
{
  m_client = client;
}
//serialize method
void Book::serialize(std::ostream & os)
{
  os << "Title: " << m_title << endl;
  if(m_cover.GetValue())
  {
    os << "Hard cover" << endl;;
  }else{
    os << "Paper back" << endl;
  }
  os << "Serial Number: " << m_serial << endl;
  if (*m_client)  
  {   
    os << "Client: " << getClient() << endl;
  }
}
//insertion operator overload
std::ostream & operator<<(std::ostream & os, Book & obj)
{
  os << obj.serialize(os);
  return os;
}