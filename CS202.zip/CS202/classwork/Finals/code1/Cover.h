#pragma once
#include <iostream>
using namespace std;

class Cover{
friend std::ostream & operator<<(std::ostream & os, const Cover & obj);
  public:
Cover(); //default constructor, sets m_hard to false
Cover(bool hard); //parametrized constructor, sets m_hard to hard
bool GetValue(); //get method, returns m_hard by value and does not modify calling object
  private:
bool m_hard; 
};

Cover::Cover()
{
  m_hard = false;
}
Cover::Cover(bool hard)
{
  m_hard = hard;
}
bool Cover::GetValue()
{
  return m_hard;
}
std::ostream & operator<<(std::ostream & os, const Cover & obj)
{
  os << obj.m_hard;
  return os;
}