#pragma once
#include <iostream>
#include <string>
using namespace std;

class Client{
friend std::ostream & operator<<(std::ostream & os, Client & obj);
  public:
Client(); //default constructor, leaves m_name uninitialized
Client(const char* name); //parametrized constructor, copies c-string name to m_name 
Client(const Client& other); //copy constructor, deep-copies data
~Client(); //destructor, deallocates memory as necessary
Client & operator=(const Client& other); //overload, deep-copies data and returns reference to calling object
char* GetName(); //get method, returns m_name by address and does not modify calling object 
  private:
char* m_name; 
};

Client::Client()
{}
Client::Client(const char* name)
{
  strcpy(m_name, name);
}
Client::Client(const Client& other)
{
  strcpy(m_name, other.m_name);
}
Client::~Client()
{}
Client & Client::operator=(const Client & other)
{
  strcpy(m_name, other.m_name);
  return *this;
}
char* Client::GetName()
{
  return m_name;
}
std::ostream & operator<<(std::ostream & os, Client & obj)
{
  os << obj.m_name;
  return os;
}