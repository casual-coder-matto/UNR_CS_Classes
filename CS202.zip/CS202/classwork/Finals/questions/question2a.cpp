#include <iostream>
using namespace std;

void rec (int n){
    if (n < 0)
    {
        cout << n << endl;
    }else{
        rec(n/10);
        cout << (n%10) << endl;
    }
}

int main()
{
    rec(123);

    return 0;
}