#include <stdio.h>

int main()
{
    int i;

    printf("Input starting value:\n");
    scanf("%d", &i);

    while (i < 1000000){
    i = i + 1;
    printf("%d\n", i);
    }

    return 0;
}