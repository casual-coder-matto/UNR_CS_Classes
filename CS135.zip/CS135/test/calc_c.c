#include <stdio.h>
#include <math.h>

int main()
{
   printf("This program impliments a calculator.\n");

   int option = 0, type = 1;
   double s, d, p, q;

   while (option != 8){
        printf("Options:\n1 - addition\n2 - subtraction\n3 - multiplication\n4 - division\n5 - exp(x)\n6 - log(x)\n7 - toggle calculator type\n8 - exit program\nPlease enter your option:");
        scanf("%d", &option);
       
       while (option != 1 && option != 2 && option != 3 && option != 4 && option != 5 && option != 6 && option != 7 && option != 8){
           printf("Invalid option.\n");

           printf("Options:\n1 - addition\n2 - subtraction\n3 - multiplication\n4 - division\n5 - exp(x)\n6 - log(x)\n7 - toggle calculator type\n8 - exit program\nPlease enter your option:");
           scanf("%d", &option);
       }
    
       switch (option){
           case 1:
                if (type == 0){
                    int a,b ;
                    printf("Enter first term:");
                    scanf("%d", &a);
                    printf("Enter second term:");
                    scanf("%d", &b);

                    printf("The sum is :%d\n", (a+b));
                }
                else{
                    double a,b;
                    printf("Enter first term:");
                    scanf("%lf", &a);
                    printf("Enter second term:");
                    scanf("%lf", &b);

                    s = a+b;
                    printf("The sum is :%.15lf\n",s);
                }
                break;
            case 2:
                if (type == 0){
                    int a, b;
                    printf("Enter first term:");
                    scanf("%d", &a);
                    printf("Enter second term:");
                    scanf("%d", &b);

                    printf("The difference is :%d\n", (a-b));
                }
                else {
                    double a, b;
                    printf("Enter first term:");
                    scanf("%lf", &a);
                    printf("Enter second term:");
                    scanf("%lf", &b);

                    d = a-b;
                    printf("The difference is :%.15lf\n",d);
                }
                break;
            case 3:
                if (type == 0){
                    int a, b;
                    printf("Enter first term:");
                    scanf("%d", &a);
                    printf("Enter second term:");
                    scanf("%d", &b);

                    printf("The product is :%d\n", (a*b));
                }
                else{
                   double a, b;
                    printf("Enter first term:");
                    scanf("%lf", &a);
                    printf("Enter second term:");
                    scanf("%lf", &b);

                    p = a*b;
                    printf("The product is :%.15lf\n",p); 
                }
                break;
            case 4:
                if (type == 0){
                    int a, b;
                    printf("Enter first term:");
                    scanf("%d", &a);
                    printf("Enter second term:");
                    scanf("%d", &b);

                    if (b == 0){
                        printf("Cannot divide by zero!");
                    }
                    else{
                        printf("The quotient is :%d\n", (a/b));
                    }    
                }
                else{
                    double a, b;
                    printf("Enter first term:");
                    scanf("%lf", &a);
                    printf("Enter second term:");
                    scanf("%lf", &b);

                    if (b == 0){
                        printf("Cannot divide by zero!\n");
                    }
                    else{
                    q = a/b;
                    printf("The quotient is :%.15lf\n",q);
                    }
                }
                break;
            case 5:
                if (type == 0){
                    int a, b;
                    printf("Cannot calculate with integers.\n");
                }
                else{
                   double a;
                    printf("Enter term:");
                    scanf("%lf", &a);
                    printf("The result of exp(%.15lf) is: %.15lf\n", a, exp(a));
                }
                break;
            case 6:
                if (type == 0){
                    int a, b;
                    printf("Cannot calculate with integers.\n");
                }
                else{
                   double a;
                    printf("Enter term:");
                    scanf("%lf", &a);
                    printf("The result of exp(%.15lf) is: %.15lf\n", a, log(a));
                }
                break;
            case 7:
                printf("Types\n0 - Integers\n1 - doubles\nChoose calculator type:");
                scanf("%d", &type);

                while (type != 0 && type != 1){
                    printf("Invalid input.\n");
                    printf("Types:\n0 - Integers\n1 - doubles\nChoose calculator type:");
                scanf("%d", &type);
                }

                if (type == 0){
                    printf("Calculator now works with integers.\n");
                }
                else{
                    printf("Calculator now works with doubles.\n");
                }
                break;
       }
   }
    printf("Exit\n");
    return 0;
}