#include <stdio.h>

int main()
{
    int i;
    float c;
    
    printf("Enter value of the trade:\n");
    scanf("%d", &i);

    if (i < 2500) {
        c = 30 + 0.017*i;
    }
        else if (2500 < i && i < 6250){
        c = 56 + .0066*i;
    }
        else if (6250 < i && i < 20000){
        c = 76 + .0034*i;
    }
        else if (20000 < i && i < 50000){
        c = 100 + .0022*i;
    }
        else if (50000 < i && i < 500000){
        c = 155 + .0011*i;
    }
    else if (i > 500000){
        c = 255 + .0009*i;
    };

    printf("Commision: $%.2f\n", c);

    return 0;
}