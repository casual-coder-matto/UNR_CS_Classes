#include <stdio.h>

int main(int argc, char* argv[])
{
    printf("%c", argv[1][0]);

    return 0;
}