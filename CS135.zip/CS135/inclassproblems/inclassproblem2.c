#include <stdio.h>

int main()
{
    int height, width, depth, density, volume, Dimensional_Weight;
    printf("Input height, width and depth with commas and a space separating the values.\n");
    scanf("%d,%d,%d", &height, &width, &depth);
    density = 166;
    volume = height*width*depth;
    Dimensional_Weight = volume/density;
    
    printf("Dimensions: %dx%dx%d\n", height, width, depth);
    printf("Volume: %d\n", volume);
    printf("Density: %d\n", density);
    printf("Dimensional Weight: %d\n", Dimensional_Weight);

    return 0;
}