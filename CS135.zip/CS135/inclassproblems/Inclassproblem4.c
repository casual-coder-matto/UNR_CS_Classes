#include <stdio.h>

int gerald(int x);

int main(){
    int x;
    printf("Enter and Integer: ");
    scanf("%d",&x);
    printf("Number of digits: %d\n",gerald(x));
    return 0;
}

int gerald(int x){
    int i;
    int count=0;
    for(int i =1;i<x;i = i*10){
        count++;
    }
    return count;
}