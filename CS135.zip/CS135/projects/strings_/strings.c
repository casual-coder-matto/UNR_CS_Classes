//Mattew Neilll project 8
#include <stdio.h>

int strlength(char* str);

char* strcopy(char* strf, char* strs);

char* strconcat(char* str_1, char* str_2);

int strcomp(char* str_1, char* str_2);

int main()
{
    char str_1[50], str_2[50];
    
    printf("Please enter the first string:");
    scanf("%s", str_1);
    //printf("%s test\n", str_1);


    printf("Please enter the second string:");
    scanf("%s", str_2);
    //printf("%s test\n", str_2);

    int l1, l2;
    l1 = strlength(str_1);
    l2 = strlength(str_2);

    printf("The length of string 1 is: %d\n", l1);
    printf("The length of string 2 is: %d\n", l2);

    int j;
    j = strcomp(str_1, str_2);

    switch(j)
    {
        case -1:
            printf("String 2 comes before string 1 alphabetically.\n");
            break;
        case 1:
            printf("String 1 comes before string 2 alphabetically.\n");
            break;
        case 0:
            printf("The two strings are the same.\n");
            break;
    }

    char* m;
    m = strconcat(str_2, str_1);

    printf("String 1 after concatenation: %s\n", str_1);
    printf("String 2 after concatenation: %s\n", str_2);

    char* n;
    n = strcopy(str_2, str_1);

    printf("String 1 after copying: %s\n", str_1);
    printf("String 2 after copying: %s\n", str_2);

    return 0;
}

int strlength(char* str)
{
    int i = 0;

    while(*str++ != '\0')
    {
        i++;
    }
    
    return i;
}

char* strcopy(char* strd, char* strs)
{
    char temp[50];
    char* beginstrd = strd;
    int l = 0;

    for(int i = 0; *strs != '\0'; i++)
    {
        temp[i] = *strs;
        *strs++;
        l++;
    }

    for(int i = 0; i < l; i++)
    {
        *strd = temp[i];
        *strd++;
    }
    *strd = '\0';

    return beginstrd;
}

char* strconcat(char* strd, char* strs)
{
    char* beginstrd = strd;

    for(int i = 0; *strd != '\0'; i++)
    {
        *strd++;
    }

    for(int i = 0; *strs != '\0'; i++)
    {
        *strd++ = *strs++;
    }
    *strd = '\0';

    return beginstrd;
}

int strcomp(char* str_1, char* str_2)
{
    int ascii_1, ascii_2;

    while(*str_1 != '\0' && *str_2 != '\0')
    {
        ascii_1 = (int)*str_1++;
        ascii_2 = (int)*str_2++;

        if(ascii_1 < 91 && ascii_1 > 65)
        {
            ascii_1 = ascii_1 + 32;
        }
        if(ascii_2 < 91 && ascii_2 > 65)
        {
            ascii_2 = ascii_2 + 32;
        }

        if(ascii_1 < ascii_2)
        {
            return 1;
        }
        else if(ascii_2 < ascii_1)
        {
            return -1;
        }
    }
    return 0;
}