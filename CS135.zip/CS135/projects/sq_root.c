// Matthew Neill
//this guesses square roots
#include <stdio.h>
#include <math.h>

int main()
{
    double test, limit = .0001;
    int guess;

    printf("Enter a number: ");
    scanf("%d", &guess);

    double old_guess = guess;

    while (fabs((old_guess*old_guess)-guess)>limit){
            printf("\n%f",old_guess);
            old_guess = (old_guess + (guess/old_guess))/2;
    }
    printf("\nEstimated square root of %d: %f\n",guess,old_guess);
    
    return 0;
}