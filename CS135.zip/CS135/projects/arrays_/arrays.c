//this code asks the user to input a 2d array and returns data//
//Matthew Neill//
#include <stdio.h>

int main()
{
    int i, j, n, m, digit[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    printf("Enter the size of the array (Row Column):");
    scanf("%d %d", &i, &j);
    int array[i][j];
    for (int n = 0; n < i; n++){
        printf("Enter row %d:", n);
        for (int m = 0; m < j; m++){
            scanf("%d", &array[n][m]);
        }
    }
    for (n = 0; n < i; n++){
        for (int m = 0; m < j; m++){
            switch (array[n][m]){
                case 0:
                digit[0]++;
                break;
                case 1:
                digit[1]++;
                break;
                case 2:
                digit[2]++;
                break;
                case 3:
                digit[3]++;
                break;
                case 4:
                digit[4]++;
                break;
                case 5:
                digit[5]++;
                break;
                case 6:
                digit[6]++;
                break;
                case 7:
                digit[7]++;
                break;
                case 8:
                digit[8]++;
                break;
                case 9:
                digit[9]++;
                break;
            }
        }
    }
    printf("Total counts for each digit:\n");
    for (int x = 0; x < 10; x++){
        printf("Digit %d occurss %d times\n", x, digit[x]);
    }
    printf("The digit counts directly from the 1D array:\n");
    for (int x = 0; x < 10; x++){
        printf("%d ", digit[x]);
    }
    printf("\nThe original 2D array entered by the user:\n");
    for (int n = 0; n < i; n++){
        for (int m = 0; m < j; m++){
            printf("%d ", array[n][m]);
        }
        printf("\n");
    }
    return 0;
}