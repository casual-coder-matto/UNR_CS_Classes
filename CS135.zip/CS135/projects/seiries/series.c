//Matthew Neill
//this calculates values of a series
#include <stdio.h>

int main()
{
    int n, i, s = 0;

    printf("Enter an integer number: ");
    scanf("%d", &n);

    for(i=1; i <= n; i++){
        if(i%2 == 0){
            s = s - (i*i);
        }
        else{
            s = s + (i*i);
        }
    }

    printf("The value of the series is: %d\n", s);
    
    return 0;
}