#include <stdio.h>

int main()
{
    int num_eggs, price_carton, lbs_bacon, price_lb, loaves_bread, price_loaf, budget;
    int max, egg, bacon, loaf;

    printf("Enter the number of eggs and price per carton:");
    scanf("%d %d", &num_eggs, &price_carton);
    printf("Enter the number of pounds of bacon and price per pound:");
    scanf("%d %d", &lbs_bacon, &price_lb);
    printf("Enter the number of loaves of bread and price per loaf:");
    scanf("%d %d", &loaves_bread, &price_loaf);
    printf("Enter Jerry's Budget:");
    scanf("%d", &budget);

    egg = num_eggs*price_carton;
    bacon = lbs_bacon*price_lb;
    loaf = loaves_bread*price_loaf;
    max = egg*bacon*loaf;

    if (budget > 0){
        printf("(1) Jerry has some money to buy breakfast supplies.\n");
        }
        else {
        printf("(1) Jerry does not have money to buy anything.\n");
        }
    if (budget >= max){
        printf("(2) Jerry can buy all the supplies for his party.\n");
        }
        else if (budget >= egg+bacon && budget < egg+loaf && budget < loaf+bacon){
                printf("(2) Jerry can only buy eggs and bacon for his party.\n");
        }
        else if (budget >= egg+loaf && budget < egg+bacon && budget < loaf+bacon){
                printf("(2) Jerry can only buy eggs and bread for his party.\n");
        }
        else if (budget >= bacon+loaf && budget < egg+bacon && budget < loaf+egg){
                printf("(2) Jerry can only buy bacon and bread for his party.\n");
        }
        else if (budget >= egg && budget < bacon+egg && budget < bacon+loaf && budget < egg+loaf){
            printf("(2) Jerry can only buy eggs for his party.\n");
        }
        else if (budget >= bacon && budget < bacon+egg && budget < bacon+loaf && budget < egg+loaf){
            printf("(2) Jerry can only buy bacon for his party.\n");
        }
        else if (budget >= loaf && budget < bacon+egg && budget < bacon+loaf && budget < egg+loaf){
            printf("(2) Jerry can only buy bread for his party.\n");
        }
        else {
            printf("(2) Jerry is going to have a very sad party.\n");
        }

    if (budget >= egg && budget < bacon && budget && budget < loaf){
        printf("(3) Only one of the breakfast supplies is cheaper than or equal to Jerry's budget.\n");
        }
        else if (budget >= bacon && budget < egg && budget && budget < loaf){
        printf("(3) Only one of the breakfast supplies is cheaper than or equal to Jerry's budget.\n");
        }
        else if (budget >= loaf && budget < bacon && budget && budget < egg){
        printf("(3) Only one of the breakfast supplies is cheaper than or equal to Jerry's budget.\n");
        }
        else {
        printf("(3) More than one of the breakfast supplies is cheaper than or equal to Jerry's budget or they are all more expensive.\n");
        }

    if (budget < egg && budget < bacon){
        printf("(4) At least two breakfast supplies are more expensive than Jerry's budget.\n");
        }
        else if (budget < egg && budget < loaf){
        printf("(4) At least two breakfast supplies are more expensive than Jerry's budget.\n");
        }
        else if (budget < loaf && budget < bacon){
        printf("(4) At least two breakfast supplies are more expensive than Jerry's budget.\n");
        }
        else {
            printf("(4) At least two breafast supplies are cheaper than or equal to Jerry's budget.\n");
        }
    
    if (egg == bacon == loaf){
        printf("(5) All the supplies cost the same.\n");
        }
        else if (egg == bacon && bacon != loaf){
            printf("(5) only two supplies cost the same.\n");
        }
        else if (egg == loaf && loaf != bacon){
            printf("(5) only two supplies cost the same.\n");
        }
        else {
            printf("(5) No supplies have the same total price.\n");
        }
    
    if (budget > egg && budget > bacon && budget > loaf){
        printf("(6) Jerry has enough money to buy any one of the three supplies.\n");
        }
        else {
            printf("(6) Jerry does not have enough money to buy any one of the three supplies.\n");
        }
    if (budget < egg && budget < bacon && budget < loaf){
        printf("(7) Jerry does not have enough money to buy any of the breakfast supplies.\n");
        }
        else {
            printf("(7) Jerry can buy at least one of the breakfast supplies.\n");
        }
    return 0;
}