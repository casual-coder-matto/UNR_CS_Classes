#include <stdio.h>

int main(int argc, char* argv[])
{
    char* fst[12], lst[15], nm[13], eml[41], mk[21], mdl[21];
    int yr[4];
    

    FILE *fpi, *fpo;

    //printf("%s\n", argv[1]);
    //printf("%s\n", argv[2]);

    fpi = fopen("%s" argv[1], "r");
    fpo = fopen("%s" argv[2], "w");

    fprint(fpc, "People eligable for recall:\n");
    fscanf(fpi,  "%s %s %s %s %s %s %d", fst, lst, nm, eml, mk, mdl, yr);

    while(fscanf(fpi, "%s %s %s %s %s %s %d", fst, lst, nm, eml, mk, mdl, yr) == 7){
        int recall = 0;
        if(mk == 'Ford' && ){
            recall = 1;
        }
    }

    return 0;
}