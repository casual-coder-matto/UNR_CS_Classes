#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>

#define SIZE 3

void display_table(char board[SIZE][SIZE]);

void clear_table(char board[SIZE][SIZE]);

bool check_table_full(char board[SIZE][SIZE]);

void update_table(char board[SIZE][SIZE], int row, int col, char move);

bool check_legal_option(char board[SIZE][SIZE], int row, int col);

void generate_player2_move(char board[SIZE][SIZE], int row, int col);

int check_three_in_a_row(char board[SIZE][SIZE]);

bool check_end_of_game(char board[SIZE][SIZE]);

void get_player1_move(char board[SIZE][SIZE], int row, int col);

void print_winner(char board[SIZE][SIZE]);

int main()
{
 char board[SIZE][SIZE], cont = 'Y';

 int row, col;

 while (cont == 'Y'){
    clear_table(board);

    display_table(board);

    do
    {
        get_player1_move(board, row, col);

        generate_player2_move(board, row, col);

     }while(check_end_of_game(board) == false);

    print_winner(board);

    printf("Would you like to play again (Y/N): ");
    scanf(" %c", &cont);
 }

 return 0;
}

void display_table(char board[SIZE][SIZE])
{
   int row, col;
   
    printf("The current state of the game is:\n");

    for(row=0; row<SIZE; row++)
    {
        for(col=0; col<SIZE; col++)
        {
            printf("%c ", board[row][col]);
        }
	printf("\n");
    }
}

void clear_table(char board[SIZE][SIZE])
{
    int row, col;
    
    for(row=0; row<SIZE; row++)
    {
        for(col=0; col<SIZE; col++)
        {
            board[row][col] = '_';
        }
    }
}

bool check_table_full(char board[SIZE][SIZE])
{
    bool full = true;
    int row, col;

    {
         for(row=0; row<SIZE; row++)
        {
            for(col=0; col<SIZE; col++)
            {
                if(board[row][col] == '_'){
                    full = false;
                }
            }
        }
    }
    return full;
}

void update_table(char board[SIZE][SIZE], int row, int col, char move)
{
    board[row][col] = move;
}

bool check_legal_option(char board[SIZE][SIZE], int row, int col)
{
    bool legal = true;

    if(row > 2 || col > 2){
        legal = false;
    }else if(board[row][col] != '_'){
        legal = false;
    }else if(row < 0 || col < 0){
	    legal = false;
    }
    
    return legal;
}

void generate_player2_move(char board[SIZE][SIZE], int row, int col)
{
    if(check_end_of_game(board)==false){
        srand(time(0));
        row = rand()%3;
        col = rand()%3;

        while(check_legal_option(board, row, col) == false){
          row = rand()%3;
          col = rand()%3;
        }


        char move = 'X';

        update_table(board, row, col, move);

        display_table(board);
    }
}

int check_three_in_a_row(char board[SIZE][SIZE])
{
    int winner = 0;

    if(board[0][0]=='O'&&board[0][1]=='O'&&board[0][2]=='O'){
        winner = 1;
    }else if(board[1][0]=='O'&&board[1][1]=='O'&&board[1][2]=='O'){
        winner = 1;
    }else if(board[2][0]=='O'&&board[2][1]=='O'&&board[2][2]=='O'){
        winner = 1;
    }else if(board[0][0]=='O'&&board[1][0]=='O'&&board[2][0]=='O'){
        winner = 1;
    }else if(board[0][1]=='O'&&board[1][1]=='O'&&board[2][1]=='O'){
        winner = 1;
    }else if(board[0][2]=='O'&&board[1][2]=='O'&&board[2][2]=='O'){
        winner = 1;
    }else if(board[0][0]=='O'&&board[1][1]=='O'&&board[2][2]=='O'){
        winner = 1;
    }else if(board[2][0]=='O'&&board[1][1]=='O'&&board[0][2]=='O'){
        winner = 1;
    }else if(board[0][0]=='X'&&board[0][1]=='X'&&board[0][2]=='X'){
        winner = 2;
    }else if(board[1][0]=='X'&&board[1][1]=='X'&&board[1][2]=='X'){
        winner = 2;
    }else if(board[2][0]=='X'&&board[2][1]=='X'&&board[2][2]=='X'){
        winner = 2;
    }else if(board[0][0]=='X'&&board[1][0]=='X'&&board[2][0]=='X'){
        winner = 2;
    }else if(board[0][1]=='X'&&board[1][1]=='X'&&board[2][1]=='X'){
        winner = 2;
    }else if(board[0][2]=='X'&&board[1][2]=='X'&&board[2][2]=='X'){
        winner = 2;
    }else if(board[0][0]=='X'&&board[1][1]=='X'&&board[2][2]=='X'){
        winner = 2;
    }else if(board[2][0]=='X'&&board[1][1]=='X'&&board[2][0]=='X'){
        winner = 2;
    }

    return winner;
}

bool check_end_of_game(char board[SIZE][SIZE])
{
    bool end = false;

    if (check_three_in_a_row(board) == 1 || check_three_in_a_row(board) == 2){
        end = true;
    } else if(check_table_full(board) == true){
        end = true;
    }

    return end;
}

void get_player1_move(char board[SIZE][SIZE], int row, int col)
{
    if(check_end_of_game(board)==false){
        printf("Player 1 enter your selection [row, col]:");
        scanf("%d, %d", &row, &col);

        row = row-1;
        col = col-1;
        
        while(check_legal_option(board, row, col) == false){
            printf("Player 1 enter your selection [row, col]:");
            scanf("%d, %d", &row, &col);

            row = row-1;
            col = col-1;
        }

        char move = 'O';

        update_table(board, row, col, move);

        display_table(board);
    }
}

void print_winner(char board[SIZE][SIZE])
{
    if (check_table_full(board) == true){
        printf("Game over, no player wins.\n");
    }else if (check_three_in_a_row(board) == 1){
        printf("Congratulations, Player 1 wins!\n");
    }else if (check_three_in_a_row(board) == 2){
        printf("Really dude? You just got beat by a random number generator.\n");
    }
}