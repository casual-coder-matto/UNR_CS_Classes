#include <stdio.h>

int main()
{
    int prt_nm, qnt;
    float prc;
    FILE *fp;
    fp = fopen("inventory.txt", "r");

    printf("Bellow are the items in your inventory\n");
    printf("Part#\tQuantity\tItem Price\n");

    while(!feof(fp))
    {
        fscanf(fp, "%d, %d, %f", &prt_nm, &qnt, &prc);
        printf("%5d\t%8d\t$%9.2f\n", prt_nm, qnt, prc);
    }
    fclose(fp);
    
    return 0;
}