#include <stdio.h>

int main()
{
    int prt_nm, qnt;
    float prc;
    FILE *fp;
    fp = fopen("inventory.txt", "w");

    printf("This program stores a business inventory.\n");

    do
    {
        printf("Please enter item data (part number, quantity, price):");
        scanf("%d, %d, %f", &prt_nm, &qnt, &prc);
        if(prt_nm == 0)
        {
            break;
        }

        fprintf(fp, "%d, %d, %f\n", prt_nm, qnt, prc);
    }while(prt_nm != 0);
    fclose(fp);

    return 0;
}