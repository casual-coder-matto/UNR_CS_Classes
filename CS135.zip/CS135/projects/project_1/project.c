#include <stdio.h>

int main()
{
    int h1, m1, s1, h2, m2, s2, h3, m3, s3, h4, m4, s4;
    char h[] = "Hours", m[] = "Minutes", s[] = "Seconds";

    printf("Enter time 1 (h:m:s):\n");
    scanf("%d:%d:%d", &h1, &m1, &s1);
    printf("Enter time 2 (h:m:s):\n");
    scanf("%d:%d:%d", &h2, &m2, &s2);
    printf("Enter time 3 (h:m:s):\n");
    scanf("%d:%d:%d", &h3, &m3, &s3);
    printf("Enter time 4 (h:m:s):\n");
    scanf("%d:%d:%d", &h4, &m4, &s4);

    printf("%-5s\t%4s\t%7s\n", h, m, s);
    printf("%-5d\t%4d\t%7d\n", h1, m1, s1);
    printf("%-5d\t%4d\t%7d\n", h2, m2, s2);
    printf("%-5d\t%4d\t%7d\n", h3, m3, s3);
    printf("%-5d\t%4d\t%7d\n", h4, m4, s4);

    return 0;
}