//Matthew Neill
//Project7
#include <stdio.h>
#include <stdbool.h>

void add(float real_part_1, float imaginary_part_1, float real_part_2, float imaginary_part_2, float* real_result, float* imaginary_result);

void subtract(float real_part_1, float imaginary_part_1, float real_part_2, float imaginary_part_2, float* real_result, float* imaginary_result);

void multiply(float real_part_1, float imaginary_part_1, float real_part_2, float imaginary_part_2, float* real_result, float* imaginary_result);

void read_num(float *real_part, float *imaginary_part);

void read_nums(float* real_part_1, float* imaginary_part_1, float* real_part_2, float* imaginary_part_2);

void print_complex(float real_part, float imaginary_part);

int main()
{
    bool calc = 1;
    int n;
    
    float real1, real2, imaginary1, imaginary2;
    float component_real=0, component_imag=0;

    printf("Complex Number Arithmetic Program:\n");

    while(calc == 1)
    {
        printf("1) Add two complex numbers\n2) Subtract two complex numbers\n) Multiply two complex numbers\n4) Divide two complex numbers\n5) Quit\nCoose an option (1 - 5): ");
        scanf("%d",&n);
        
        if(n == 1 || n == 2 || n == 3 || n == 4)
        {
            switch(n)
            {
                case 1:
                    add(real1, imaginary1, real2, imaginary2, &component_real, &component_imag);
                    print_complex(component_real, component_imag);
                    break;
                case 2:
                    subtract(real1, imaginary1, real2, imaginary2, &component_real, &component_imag);
                    print_complex(component_real, component_imag);
                    break;
                case 3:
                    multiply(real1, imaginary1, real2, imaginary2, &component_real, &component_imag);
                    print_complex(component_real, component_imag);
                    break;
                case 4:
                    printf("Bye!\n");
                    calc = 0;
                    break;
            }
        }else
        {
            printf("Please input a valid menu option\n");
        }
    }

    return 0;
}

void read_num(float *real_part, float *imaginary_part)
{
    float imaginary, real;

    printf("Please type in the real component: ");
    scanf("%f",&real);
    printf("Please type in the imaginary component: ");
    scanf("%f",&imaginary);

    *real_part = real;
    *imaginary_part = imaginary;
}

void read_nums(float* real_part_1, float* imaginary_part_1, float* real_part_2, float* imaginary_part_2)
{
    float real1, imaginary1, real2, imaginary2;
    
    printf("Reading the first imaginary number...\n");
    read_num(&real1, &imaginary1);

    *real_part_1 = real1;
    *imaginary_part_1 = imaginary1;

    printf("Reading the second imaginary number...\n");
    read_num(&real2, &imaginary2);

    *real_part_2 = real2;
    *imaginary_part_2 = imaginary2;
}
void print_complex(float real_part, float imaginary_part)
{
    printf("The operation yields %0.3f + %0.3fi\n", real_part, imaginary_part);
}

void add(float real_part_1, float imaginary_part_1, float real_part_2, float imaginary_part_2, float* real_result, float* imaginary_result)
{
    read_nums(&real_part_1, &imaginary_part_1, &real_part_2, &imaginary_part_2);
    *real_result = real_part_1 + real_part_2;
    *imaginary_result = imaginary_part_1 + imaginary_part_2;
}

void subtract(float real_part_1, float imaginary_part_1, float real_part_2, float imaginary_part_2, float* real_result, float* imaginary_result)
{
    read_nums(&real_part_1, &imaginary_part_1, &real_part_2, &imaginary_part_2);
    *real_result = real_part_1 - real_part_2;
    *imaginary_result = imaginary_part_1 - imaginary_part_2;
}

void multiply(float real_part_1, float imaginary_part_1, float real_part_2, float imaginary_part_2, float* real_result, float* imaginary_result)
{
    read_nums(&real_part_1, &imaginary_part_1, &real_part_2, &imaginary_part_2);
    *real_result = (real_part_1 * real_part_2)-(imaginary_part_1 * imaginary_part_2);
    *imaginary_result = (imaginary_part_1*real_part_2) + (imaginary_part_2*real_part_1);
}